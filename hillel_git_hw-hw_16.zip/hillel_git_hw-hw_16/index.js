$(document).ready(function(){
    $('.section-info__team-slider').slick({
        dots: true,
        infinite: true
    });
  });